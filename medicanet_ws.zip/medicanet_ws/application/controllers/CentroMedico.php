<?php
defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'controllers/Api.php';

class CentroMedico extends Api
{       
    public function __construct()
    {                    
        parent::__construct();        
        $this->load->model("CentroMedicoModel");
    }
    public function centro_medico_get()
    {        
        $api = new Api();
        // Call the verification method and store the return value in the variable
        $data = $api->verify_request();
        // Send the return data as reponse
        $status = parent::HTTP_OK;
        $list = $this->CentroMedicoModel->getLista($data);
        // if(!is_null($list)){
        //     $this->response(array('resp' => $list),200);
        // }else {
        //     $this->response(array('resp'=>'No hay registros'),404);
        // }
        // $response = ['status' => $status, 'data' => $data];
        $response = $list;
        $this->response($response, $status);
    }
}