<?php
defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'controllers/Api.php';

class TestApi extends Api
{       
    public function __construct()
    {            
        parent::__construct();
    }
    public function get_me_data_post()
    {
        $api = new Api();
        // Call the verification method and store the return value in the variable
        $data = $api->verify_request();
        // Send the return data as reponse
        $status = parent::HTTP_OK;
        $response = ['status' => $status, 'data' => $data];
        $this->response($response, $status);
    }
}
