<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// Store your secret key here
// Make sure you use better, long, more random key than this
$config['jwt_key'] = 'a1s2d3_d9s8a7';