<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MedicosModel extends CI_Model {
    public function getLista() { 
        $query = "SELECT * FROM tbl_med_medico";
        $result = $this->db->query($query);
        return $result->result();
    }
	public function getListaPorCentroMedico($data) { 
        $query = "SELECT * FROM tbl_med_medico JOIN tbl_mac_medico_atiende_centro_medico"+
                  " ON med_codigo = mac_codmed WHERE med_codcmd = " + $data["cmd"];
        $result = $this->db->query($query);
        return $result->result();
    }
    public function getListaPorEspecialidad($data) { 
        $query = "SELECT * FROM tbl_med_medico JOIN tbl_emm_especialidad_medica_medico"+
                  " ON med_codigo = emm_codmed WHERE emm_codemd = " + $data["emd"];
        $result = $this->db->query($query);
        return $result->result();
    }
    // public function guardarDatos($id, $data){
    //     if (!empty($id) && $id > 0) {
    //         $stored_procedure = "CALL proc_crud_asignacion(3,?,?,?,?,?,?,?)";
    //     }else {
    //         $stored_procedure = "CALL proc_crud_asignacion(2,?,?,?,?,?,?,?)";
    //     }        
    //     $result = $this->db->query($stored_procedure, $data);
    //     return $result;
    // }

    // //Este no es un delete a la bd sino que update de estado: activo/inactivo
    // public function borrarDatos($data) {
    //     $stored_procedure = "CALL proc_crud_asignacion(4,?,?,?,?,?,?,?)";
    //     $result = $this->db->query($stored_procedure, $data);
    //     return $result;
    // }

}