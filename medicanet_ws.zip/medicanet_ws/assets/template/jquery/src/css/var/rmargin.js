define( function() {
	return ( /^margin/ );
} );
